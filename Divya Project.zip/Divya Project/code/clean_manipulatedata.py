import selenium
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd

# Set up the webdriver
driver = webdriver.Chrome()

def extract_data(url, search_query, css_selector):
    driver.get(url)
    search_bar = driver.find_element(By.ID, search_query)
    search_bar.send_keys("iPhone")
    search_bar.submit()
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, css_selector)))
    data = []
    for item in driver.find_elements(By.CSS_SELECTOR, css_selector):
        model = item.find_element(By.CSS_SELECTOR, ".a-size-medium.a-color-base.a-text-normal").text
        price = item.find_element(By.CSS_SELECTOR, ".a-price-whole").text
        data.append({"Model": model, "Price": price})
    return data

# Extract data from Amazon
amazon_data = extract_data("https://www.amazon.in/", "twotabsearchtextbox", ".s-result-item")

# Extract data from Flipkart
flipkart_data = extract_data("https://www.flipkart.com/", "search_query", ".product-unit")

# Close the webdriver
driver.quit()

# Create dataframes
amazon_df = pd.DataFrame(amazon_data)
flipkart_df = pd.DataFrame(flipkart_data)

# Clean the data
amazon_df["Price"] = amazon_df["Price"].str.replace(",", "").astype(int)
flipkart_df["Price"] = flipkart_df["Price"].str.replace(",", "").astype(int)

# Merge the dataframes
merged_df = pd.merge(amazon_df, flipkart_df, on="Model", suffixes=("_Amazon", "_Flipkart"))

merged_df.to_csv("price_comparison.csv", index=False)