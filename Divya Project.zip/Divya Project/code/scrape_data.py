from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time

def extract_data(url, search_field_id, result_class_name):
    # Navigate to the URL
    driver.get(url)

    # Find the search field and enter the search query
    search_field = driver.find_element_by_id(search_field_id)
    search_field.send_keys("product name")
    search_field.send_keys(Keys.RETURN)

    # Wait for the search results to load
    time.sleep(5)

    # Find the search results and extract the data
    results = driver.find_elements_by_css_selector(result_class_name)
    data = []
    for result in results:
        data.append(result.text)

    return data

# Set up the webdriver
driver = webdriver.Chrome()

# Extract data from Amazon
amazon_data = extract_data("https://www.amazon.in/", "twotabsearchtextbox", ".s-result-item")

# Extract data from Flipkart
flipkart_data = extract_data("https://www.flipkart.com/", "search_query", ".product-unit")

# Close the webdriver
driver.quit()